﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Logistics.LC_Index
{
    public partial class LC_Index :PageLoginBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}