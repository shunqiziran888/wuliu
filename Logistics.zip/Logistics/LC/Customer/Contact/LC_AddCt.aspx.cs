﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CustomExtensions;
namespace Logistics.LC.Customer.Contact
{
    public partial class LC_AddCt : PageLoginBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
            
        }
    }
}