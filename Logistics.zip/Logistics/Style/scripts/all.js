document.write("<scri" + "pt src='/Style/scripts/zepto.min.js'></sc" + "ript>");
document.write("<scri" + "pt src='/Style/scripts/sm.min.js'></sc" + "ript>");
document.write("<scri" + "pt src='/Style/scripts/sm-extend.min.js'></sc" + "ript>");
document.write("<scri" + "pt src='/Style/scripts/tools.js'></sc" + "ript>");
