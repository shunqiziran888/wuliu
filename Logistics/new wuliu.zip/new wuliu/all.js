document.write("<scri" + "pt src='../js/zepto.min.js'></sc" + "ript>");
document.write("<scri" + "pt src='../js/sm.min.js'></sc" + "ript>");
document.write("<scri" + "pt src='../js/sm-extend.min.js'></sc" + "ript>");